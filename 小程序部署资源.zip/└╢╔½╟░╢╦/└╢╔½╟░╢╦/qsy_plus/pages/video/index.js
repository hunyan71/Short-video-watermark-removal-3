var a = getApp(),
    t = 1;

Page({
    data: {
        videolist: [],
        list: [],
        isAudit: "0",
        tuijian: [],
        url: "",
        loginState: "0",
        invite_award: "",
        shareTitle: "",
        imageUrl: "",
        spnum: "",
        tsnum: "",
        maxnum: "",
        adspid: "",
        nowtime: Date.parse(new Date()),
        lastday: "",
        lasttime: "",
        guankan:'',
        show: !1
    },
    onLoad: function(a) {
        if (wx.getStorageSync("invita_openid").length < 5) {
            var i = a.openid || "";
            wx.setStorageSync("invita_openid", i);
        }
        this.pageRequest(t);
        var lastday = wx.getStorageSync('lastday')
        var lasttime = wx.getStorageSync('lasttime')
        this.setData({
            lastday: lastday,
            lasttime: lasttime,
        });
    },
    onShow: function(t) {
        var e = this;
        a.util.request({
            url: "entry/wxapp/member",
            success: function(a) {
                console.log(a.data.data), a.data.data.user ? e.setData({
                    loginState: 1,
                }) : e.setData({
                    loginState: 0,
                });
            },
            fail: function() {
                e.setData({
                    loginState: 0,
                });
            }
        });
    },
    onPullDownRefresh: function() {
        this.setData({
            videolist: [],
            list: []
        }), t = 1, this.pageRequest(t);
    },
    pageRequest: function(i) {
        var e = this;
        a.util.request({
            url: "entry/wxapp/video",
            data: {
                pages: i
            },
            success: function(a) {
                wx.setStorageSync("isAudit", a.data.data.isaudit.isaudit),
                    wx.setStorageSync("num", a.data.data.isaudit.qq_group),
                    wx.setStorageSync("wxnum", a.data.data.isaudit.adtext),
                    wx.setStorageSync("jlsp", a.data.data.isaudit.help_url),
                    console.log(a.data), wx.setNavigationBarTitle({
                        title: "0" == a.data.data.isaudit.isaudit ? "热门推荐" : "热门推荐"
                    }), e.setData({
                        isAudit: a.data.data.isaudit.isaudit,
                        tuijian: a.data.data.tuijian,
                        url: a.data.data.url,
                        adimg: a.data.data.isaudit.adimg,
                        invite_award: a.data.data.isaudit.invite_award,
                        shareTitle: a.data.data.isaudit.share_title,
                        adspid: a.data.data.isaudit.dayadid,
                        spnum: a.data.data.isaudit.qq_group,
                        tsnum: a.data.data.isaudit.adtext,
                        maxnum: a.data.data.isaudit.mix_num,
                        adId: a.data.data.isaudit.copytext,
                        guankan:a.data.data.isaudit.guankan,
                        imageUrl: a.data.data.isaudit.share_img
                    }), 0 == a.data.data.length ? e.setData({
                        list: a.data.data.videolist,
                        show: !0
                    }) : (e.setData({
                        list: a.data.data.videolist,
                        videolist: e.data.videolist.concat(a.data.data.videolist)
                    }), t++);
            }
        });
    },
    qd: function() {
        if (this.data.loginState == 1) {
        var a = this,
            t = wx.createRewardedVideoAd({
                adUnitId: a.data.adspid
            });
        t.load().then(function() {
            return t.show();
        }).catch(function(a) {
            return console.log(a.errMsg);
        }), t.onError(function(t) {
            console.log(t), a.copydownurls();
        }), t.onClose(function(i) {
            t.offClose(), i && i.isEnded || void 0 === i ? a.isqd() : wx.showModal({
                title: "温馨提示",
                content: "看完广告后获得\r\n" + a.data.spnum + "次解析次数!",
                showCancel: !0,
                cancelText: "不看了",
                cancelColor: "#52bcff",
                confirmText: "继续看",
                confirmColor: "#ed3f14",
                success: function(t) {
                    t.cancel || a.qd();
                }
            });
        });
    }else {
        wx.showModal({
            title: "温馨提示",
            content: "请登录后观看",
            showCancel: true,
            cancelText: "取消",
            cancelColor: "#52bcff",
            confirmText: "确定",
            confirmColor: "#ed3f14",
            success: function(a) {
                a.cancel;
            }
        });
    }
    },
    isqd: function() {
        a.util.request({
            url: "entry/wxapp/Add",
            success: function(a) {
                console.log("温馨提示"), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            },
            fail: function(a) {
                console.log(a), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            }
        });
        var lasttime = Number(Date.parse(new Date())) + Number(86400000);
        wx.setStorageSync('lasttime', lasttime)
        var lasttime = wx.getStorageSync('lasttime')
        console.log('次数缓存过期时间',lasttime),
        this.setData({
            lasttime : lasttime,
        });
    },

    wxcs: function() {
        if (this.data.loginState == 1) {
        let a = this,
            t = wx.createRewardedVideoAd({
                adUnitId: a.data.adspid
            });
        t.load().then(function() {
            return t.show();
        }).catch(function(a) {
            return console.log(a.errMsg);
        }), t.onError(function(t) {
            console.log(t), a.copydownurls();
        }), t.onClose(function(i) {
            t.offClose(), i && i.isEnded || void 0 === i ? a.iswxcs() : wx.showModal({
                title: "温馨提示",
                content: "看完广告后获得\r\n" + a.data.tsnum + "天无限解析VIP会员!",
                showCancel: !0,
                cancelText: "不看了",
                cancelColor: "#52bcff",
                confirmText: "继续看",
                confirmColor: "#ed3f14",
                success: function(t) {
                    t.cancel || a.wxcs();
                }
            });
        });
    }else {
        wx.showModal({
            title: "温馨提示",
            content: "请登录后观看",
            showCancel: true,
            cancelText: "取消",
            cancelColor: "#52bcff",
            confirmText: "确定",
            confirmColor: "#ed3f14",
            success: function(a) {
                a.cancel;
            }
        });
    }
    },
    iswxcs: function() {
        a.util.request({
            url: "entry/wxapp/wxcs",
            success: function(a) {
                console.log("温馨提示"), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            },
            fail: function(a) {
                console.log(a), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            }
        });
        var lastday=  Number(Date.parse(new Date())) + Number(86400000);
        wx.setStorageSync('lastday', lastday)
        var lastday = wx.getStorageSync('lastday')
        console.log('VIP缓存过期时间',lastday),
        this.setData({
            lastday : lastday,
        });
    },
    last: function() {
        wx.showModal({
            title: "温馨提示",
            content: "您今天已经看过啦\r\n明天再来观看吧",
            showCancel: true,
            cancelText: "取消",
            cancelColor: "#52bcff",
            confirmText: "确定",
            confirmColor: "#ed3f14",
            success: function(a) {
                a.cancel;
            }
        });
    },
    gologin: function(){ wx.switchTab({ url: '../member/index', }) },
    loadMore: function() {
        0 == this.data.list.length || this.pageRequest(t);
    },
    onShareAppMessage: function(a) {
        var t = this;
        return a.from, {
            title: t.data.shareTitle,
            path: "/qsy_plus/pages/index/index?openid=" + wx.getStorageSync("share_openid"),
            imageUrl: this.data.url + this.data.imageUrl
        };
    }
});