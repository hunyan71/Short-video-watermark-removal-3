var util = require('we7/resource/js/util.js');
const accountInfo = wx.getAccountInfoSync();
console.log(accountInfo.miniProgram.appId)
App({
  onLaunch () {
    wx.setStorageSync("appid", accountInfo.miniProgram.appId)
    if (wx.canIUse('getUpdateManager')) {
      const updateManager = wx.getUpdateManager()
      updateManager.onCheckForUpdate(function (res) {
        if (res.hasUpdate) {
          updateManager.onUpdateReady(function () {
            wx.showModal({
              title: '更新提示',
              content: '新版本已经准备好，是否重启应用？',
              success: function (res) {
                if (res.confirm) {
                  updateManager.applyUpdate()
                }
              }
            })
          })
          updateManager.onUpdateFailed(function () {
            wx.showModal({
              title: '已经有新版本了哟~',
              content: '新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~'
            })
          })
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },
	
    onShow: function (res) {
    
    // wx.getUpdateManager 在 1.9.90 才可用，请注意兼容
    const updateManager = wx.getUpdateManager()
    updateManager.onCheckForUpdate(function (res) {
 // 请求完新版本信息的回调
 console.log(res.hasUpdate)
    })
    updateManager.onUpdateReady(function () {
     wx.showModal({
     title: '更新提示',
     content: '新版本已经准备好，是否马上重启小程序？',
     success: function (res) {
     if (res.confirm) {
       // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
       updateManager.applyUpdate()
      }
    }
  })
 })
 
 updateManager.onUpdateFailed(function () {
 // 新的版本下载失败
 })
		
    },


    onError: function (msg) {
        //console.log(msg)
    },
    //加载微擎工具类
    util: util,
    //导航菜单，微擎将会自己实现一个导航菜单，结构与小程序导航菜单相同
    //用户信息，sessionid是用户是否登录的凭证
    userInfo: {
        sessionid: null,
    },
    siteInfo: require('siteinfo.js'),
    globalData: {
      api_url: null,
      progress: null,
      adid: null,
      wxid: null,
      day: null,
      ad: null,
      banner: null,
    },
});