Page({
    data: {},
    onShareAppMessage: function(a) {
        return {
            title: wx.getStorageSync("name"),
            path: "/qsy_plus/pages/help/index?openid=" + wx.getStorageSync("share_openid"),
            imageUrl: wx.getStorageSync("share")
        };
    },
});