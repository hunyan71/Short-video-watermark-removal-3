function t(t, a, o) {
    return a in t ? Object.defineProperty(t, a, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = o, t;
  }
  var time = require('../../resource/js/time.js');
  var a = require("../../../fast.fd521.cn.js"),
    e = getApp();
  var util = require('../../resource/js/lanch.js');
  const md5 = require('../../resource/js/md5.js');
  var app = getApp();
  Page({
    data: (a = {
            showTopTips: !1,
            inputvalue: "",
            url: "",
            adid: "",
            userinfo: "",
            video: "", 
            id: "",
            cursor: "",
            end: "1",
            more: "1",
            total: 0,
            page: 1,
            pagesize: 10,
　　　　     onRefresh: true,
            zzlist:[]
        }, a),
    onLoad: function(options) {
        this.getList();
        this.setData({
            adid: getApp().globalData.banner,
        });
        wx.setNavigationBarTitle({
            title: "批量解析",
        })
    },
  
    swiperChange: function(e) {
        this.setData({
            swiperCurrent: e.detail.current
        })
    },
    onShow: function(res) {
        let that = this;
        wx.getClipboardData({
            success: function(res) {
                let result = util.handleUrl(res.data);
                if (result && result !== that.data.inputvalue) {
                    let txturl = result.substring(0, 30)
                    if(that.data.more > 0){
                    wx.showModal({
                        title: '检测到视频链接，是否粘贴？',
                        content: txturl.length >= 30 ? txturl + '...' : result,
                        showCancel: true,
                        cancelText: "取消",
                        cancelColor: '#52bcff',
                        confirmText: "粘贴",
                        confirmColor: '#52bcff',
                        success: function(res) {
                            if (res.cancel) {} else {
                                that.setData({
                                    inputvalue: result,
                                   //downurl: ""
                                })
                            }
                        },
                        fail: function(res) {},
                        complete: function(res) {},
                    })
                }
  
                }
            },
            fail: function(res) {},
            complete: function(res) {},
        })
        that.index()
        wx.checkSession({
            success: function(e) {
                console.log("没过期");
                that.setData({
                    loginState: 1
                })
            },
            fail: function() {
                console.log("过期了");
                that.setData({
                    loginState: 0
                })
            }
        });
    },
  
    start: function() {
        let that = this;
        that.setData({
            color: '#ffb428'
        })
    },
    end: function() {
        let that = this;
        that.setData({
            color: '#faa508'
        })
    },
    warn: function() {
        wx.showModal({
            title: '温馨提示',
            content: "请先登陆!",
            confirmColor: "#52bcff",
            showCancel: false,
            success: function(res) {
                wx.navigateTo({ url: '../member/index', })
            }
        })
    },
    changeLoginState: function() {
        this.setData({
            loginState: 0
        })
    },
    invalue: function(e) {
        this.setData({
            inputvalue: e.detail.value
        })
    },
    clear: function() {
        this.setData({
            inputvalue: ''
        })
    },
    index: function() {
        let that = this;
        let adIdList = [];
        app.util.request({
            'url': 'entry/wxapp/index',

        })
    },
  
    paste: function() {
        let that = this;
        wx.getClipboardData({
            success: function(res) {
                let result = util.handleUrl(res.data);
                if (result) {
                    that.setData({
                        inputvalue: result
                    })
                } else(
                    wx.showModal({
                        title: '温馨提示',
                        content: "没有可用的链接",
                        confirmColor: "#52bcff",
                        showCancel: false,
                        success: function(res) {
                            that.setData({
                                result: ''
                            })
                        }
                    })
                )
  
            }
        })
  
    },
    query0: time.throttle(function(e) {
        let that = this;
        let gurl = that.isUrl(that.data.inputvalue);
        var string = gurl;
        string = md5.md5(that.data.inputvalue);
        if (gurl) {
            wx.showLoading({
                title: '正在解析'
            })
            app.util.request({
                'url': 'entry/wxapp/query',
                'data': {
                    url: gurl,
                    encrypt: string
                },
                success(res) {
                    that.setData({
                        key: "video",
                        data: res.data.data
                    })
                    wx.navigateTo({
                        url: '../result/index'
                    })
                },
                fail(res) {
                    let err = res.data.errno
                    wx.hideToast({})
                    wx.showModal({
                        title: '温馨提示',
                        content: res.data.message,
                        confirmColor: "#52bcff",
                        showCancel: false,
                        success: function(res) {
                            if (err === 3) {
                                wx.removeStorage({
                                    key: 'userInfo',
                                    success(res) {
                                        that.setData({
                                            loginState: "0"
                                        })
                                        wx.reLaunch({
                                            url: '../index/index'
                                        })
                                    }
                                })
                            }
                        }
                    })
  
                }
            })
        }
    }, 3000),
  
    query: time.throttle(function(e) {
        let that = this;
        that.setData({
            video: [],
            userinfo: "",
            video: "", 
            id: "",
            cursor: "",
            end: "1",

        })
        let gurl = that.isUrl(that.data.inputvalue);
        if (gurl) {
            wx.showLoading({
                title: '正在解析'
            })
            app.util.request({
                'url': 'entry/wxapp/querytwo',
                'data': {
                    url: gurl,
                },
                success(res) {
                    if(res.data.errno==0){
                         that.setData({
                            zzlist: res.data.data,
                            num: res.data.data.length,
                            // id: res.data.data.id,
                        })
                        
                    }
                    console.log(res)
                    // that.setData({
                    //     userinfo: res.data.data,
                    //     num: res.data.data.num,
                    //     id: res.data.data.id,
                    // })
                    // that.getList()
                },
                fail(res) {
                    let err = res.data.errno
                    wx.hideToast({})
                    if (err === 5) {
                        wx.showModal({
                            title: '温馨提示',
                            content: '您的次数已用完！\r\n观看完广告后可获得VIP会员\r\n会员有效期间内可无限制解析视频',
                            showCancel: true,
                            cancelText: "下次再说",
                            cancelColor: '#52bcff',
                            confirmText: "观看视频",
                            confirmColor: '#ed3f14',
                            success: function(res) {
                                res.cancel || that.wxcs();
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../index/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 0) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../index/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 1) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../index/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 3) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../index/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                }
            })
        }
    }, 3000),
  
  
    wxcs: function() {
        var a = this,
            t = wx.createRewardedVideoAd({
                adUnitId: a.data.adspid
            });
        t.load().then(function() {
            return t.show();
        }).catch(function(a) {
            return console.log(a.errMsg);
        }), t.onError(function(t) {
            console.log(t), a.error();
        }), t.onClose(function(i) {
            t.offClose(), i && i.isEnded || void 0 === i ? a.cs() : wx.showModal({
                title: "温馨提示",
                content: "看完广告后可获得\r\n无限解析VIP会员奖励!",
                showCancel: !0,
                cancelText: "不看了",
                cancelColor: "#52bcff",
                confirmText: "继续看",
                confirmColor: "#ed3f14",
                success: function(t) {
                    t.cancel || a.wxcs();
                }
            });
        });
    },
  
    cs: function() {
        let that = this;
        app.util.request({
            url: "entry/wxapp/wxcs",
            data: {
                tsnum: that.data.jlnum
            },
            success: function(a) {
                console.log("温馨提示"), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            },
            fail: function(a) {
                console.log(a), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            }
        });
    },
    error: function() {
        wx.showModal({
            title: '温馨提示',
            content: "观看失败",
            confirmColor: "#52bcff",
            showCancel: false,
        })
    },
  
    isUrl: function(url) {
        var that = this;
        if (url.length == 0) {
            wx.showModal({
                title: '温馨提示',
                content: "网址不能为空",
                confirmColor: "#52bcff",
                showCancel: false,
            })
            return false;
        } else {
            let result = util.handleUrl(url);
            if (result) {
                return result;
            } else {
                wx.showModal({
                    title: '温馨提示',
                    content: "请输入正确的网址",
                    confirmColor: "#52bcff",
                    showCancel: false,
                    success: function(res) {
                        that.setData({
                            result: ''
                        })
                    }
                })
                return false;
            }
        }
    },

  onReachBottom: function () {
    console.log('加载中。。。');
    wx.showLoading({
      title: '加载中',
    });   
    var that = this;
      that.setData({
        onRefresh: true
    });
    this.getList();
  },

    onShareAppMessage: function(t) {
        return t.from, {
            title: this.data.shareTitle,
            path: "/qsy_plus/pages/index/index?openid=" + wx.getStorageSync("share_openid"),
            imageUrl: this.data.share_img
        };
    },
    onShareTimeline() {
        return {
            title: this.data.shareTitle,
            path: "/qsy_plus/pages/index/index?openid=" + wx.getStorageSync("share_openid"),
            imageUrl: this.data.share_img
        }
    },

  getList: function () {
    var that=this;
    var onRefresh = that.data.onRefresh;
    app.util.request({
      'url': 'entry/wxapp/videolist',
      data: {
            id: that.data.id,
            cursor: that.data.cursor,
      },
      success: function (res) {
        var datas = res.data.data;
        console.log(datas);
        if(that.data.more > 0){
          if(onRefresh){
            if(that.data.video.length > 0){
            that.setData({
              video: that.data.video.concat(datas.video),
              cursor: datas.cursor,
              page: that.data.page + 1,
              more: datas.has_more,
            });
        }else{
            that.setData({
                video: datas.video,
                cursor: datas.cursor,
                more: datas.has_more,
                page: that.data.page + 1
            });
        }
          }else{
            that.setData({
              video: datas.video,
              cursor: datas.cursor,
              more: datas.has_more,
              page: that.data.page + 1
            });
          }
          
        }else{
          wx.showToast({
            title:'没有更多数据了',
            icon:'none'
          })
          that.setData({
              isloading:true
          })

          }
      },
      complete : function(res){
        wx.hideLoading();
      },
      fail: function (res) {
        console.log('load fail');
        
      }
    })
  },
  goresult:function(a){
    wx.showToast({
        title: '加载中',
        icon: 'loading',
        duration: 10000
        });
    var i = this,
    n = a.currentTarget.dataset.id,
    // r = i.data.video[n];
    r = i.data.zzlist[n];
    let video = r;
    console.log(video)

            wx.navigateTo({
                url: '../result/index'
            })
            wx.setStorage({
                key: "video",
                data: video
            })
    // app.util.request({
    //     'url': 'entry/wxapp/Getvideolist',
    //     data: {
    //         playAddr: video.downurl,
    //     },
    //     success(res) {
    //         console.log(res.data)
    //         wx.hideToast();
    //         wx.setStorage({
    //             key: "video",
    //             data: res.data.data
    //         })
           
    //         wx.navigateTo({
    //             url: '../result/index'
    //         })
    //     },

    // })

},
  });