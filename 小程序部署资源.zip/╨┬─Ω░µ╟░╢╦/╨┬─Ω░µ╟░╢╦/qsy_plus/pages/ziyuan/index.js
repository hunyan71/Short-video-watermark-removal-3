var a = getApp(),
    t = 1;
   var n = require("../../../utils/cache.js");
Page({
    data: {
        videolist: [],
        list: [],
        isAudit: "0",
        ziyuan: [],
        url: "",
        adId: "",
        ad_id: "",
        jiaocheng: "",
        loginState: "0",
        invite_award: "",
        shareTitle: "",
        imageUrl: "",
        spnum: "",
        jiaocheng_img: "",
        tsnum: "",       
        maxnum: "",
        adspid: "",
        nowtime: Date.parse(new Date()),
        lastday: "",
        lasttime: "",
        show: !1,
        keyindex:0
    },
    onLoad: function(a) {
        if (wx.getStorageSync("invita_openid").length < 5) {
            var i = a.openid || "";
            wx.setStorageSync("invita_openid", i);
        }
        this.pageRequest(t);
        var lastday = wx.getStorageSync('lastday')
        var lasttime = wx.getStorageSync('lasttime')
        this.setData({
            lastday: lastday,
            lasttime: lasttime,
        });
    },
    
    onShow: function(t) {
        var e = this;
        a.util.request({
            url: "entry/wxapp/member",
            success: function(a) {
                console.log(a.data.data), a.data.data.user ? e.setData({
                    loginState: 1,
                }) : e.setData({
                    loginState: 0,
                });
            },
            fail: function() {
                e.setData({
                    loginState: 0,
                });
            }
        });
    },
    onPullDownRefresh: function() {
        this.setData({
            videolist: [],
            list: []
        }), t = 1, this.pageRequest(t);
    },
    pageRequest: function(i) {
        var e = this;
        a.util.request({
            url: "entry/wxapp/video",
            data: {
                pages: i
            },
            success: function(a) {
                wx.setStorageSync("isAudit", a.data.data.isaudit.isaudit),
                    wx.setStorageSync("num", a.data.data.isaudit.qq_group),
                    wx.setStorageSync("wxnum", a.data.data.isaudit.adtext),
                    wx.setStorageSync("jlsp", a.data.data.isaudit.help_url),
                    console.log(a.data.data.ziyuan), wx.setNavigationBarTitle({
                        title: "0" == a.data.data.isaudit.isaudit ? "免费资源" : "免费资源"
                    }), e.setData({
                        isAudit: a.data.data.isaudit.isaudit,
                        ziyuan: a.data.data.ziyuan,                        
                        jiaocheng:  a.data.data.isaudit.jiaocheng,
                        ad_id:  a.data.data.isaudit.ad_id,
                        jiaocheng_img: a.data.data.isaudit.jiaocheng_img,
                        url: a.data.data.url,
                        adimg: a.data.data.isaudit.adimg,
                        invite_award: a.data.data.isaudit.invite_award,
                        shareTitle: a.data.data.isaudit.share_title,
                        adspid: a.data.data.isaudit.dayadid,
                        spnum: a.data.data.isaudit.qq_group,
                        tsnum: a.data.data.isaudit.adtext,
                        maxnum: a.data.data.isaudit.mix_num,
                        adId: a.data.data.isaudit.copytext,
                        imageUrl: a.data.data.isaudit.share_img
                    }), 0 == a.data.data.length ? e.setData({
                        list: a.data.data.videolist,
                        show: !0
                    }) : (e.setData({
                        list: a.data.data.videolist,
                        videolist: e.data.videolist.concat(a.data.data.videolist)
                    }), t++);
            }
        });
    },
    qd: function() {
        if (this.data.loginState == 1) {
        var a = this,
            t = wx.createRewardedVideoAd({
                adUnitId: a.data.jiaocheng
            });
        t.load().then(function() {
            return t.show();
        }).catch(function(a) {
            return console.log(a.errMsg);
        }), t.onError(function(t) {
            console.log(t), a.copydownurls();
        }), t.onClose(function(i) {
            t.offClose(), i && i.isEnded || void 0 === i ? a.isqd() : wx.showModal({
                title: "温馨提示",
                content: "看完广告后获得\r\n" + a.data.spnum + "次解析次数!",
                showCancel: !0,
                cancelText: "不看了",
                cancelColor: "#00baff",
                confirmText: "继续看",
                confirmColor: "#ed3f14",
                success: function(t) {
                    t.cancel || a.qd();
                }
            });
        });
    }else {
        wx.showModal({
            title: "温馨提示",
            content: "请登录后观看",
            showCancel: true,
            cancelText: "取消",
            cancelColor: "#00baff",
            confirmText: "确定",
            confirmColor: "#ed3f14",
            success: function(a) {
                a.cancel;
            }
        });
    }
    },
    isqd: function() {
        a.util.request({
            url: "entry/wxapp/Add",
            success: function(a) {
                console.log("温馨提示"), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#00baff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            },
            fail: function(a) {
                console.log(a), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#00baff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            }
        });
        var lasttime = Number(Date.parse(new Date())) + Number(86400000);
        wx.setStorageSync('lasttime', lasttime)
        var lasttime = wx.getStorageSync('lasttime')
        console.log('次数缓存过期时间',lasttime),
        this.setData({
            lasttime : lasttime,
        });
    },

    wxcs: function() {
        if (this.data.loginState == 1) {
        let a = this,
            t = wx.createRewardedVideoAd({
                adUnitId: a.data.jiaocheng
            });
        t.load().then(function() {
            return t.show();
        }).catch(function(a) {
            return console.log(a.errMsg);
        }), t.onError(function(t) {
            console.log(t), a.copydownurls();
        }), t.onClose(function(i) {
            t.offClose(), i && i.isEnded || void 0 === i ? a.iswxcs() : wx.showModal({
                title: "温馨提示",
                content: "看完广告后获得\r\n" + a.data.tsnum + "天无限解析VIP会员!",
                showCancel: !0,
                cancelText: "不看了",
                cancelColor: "#00baff",
                confirmText: "继续看",
                confirmColor: "#ed3f14",
                success: function(t) {
                    t.cancel || a.wxcs();
                }
            });
        });
    }else {
        wx.showModal({
            title: "温馨提示",
            content: "请登录后观看",
            showCancel: true,
            cancelText: "取消",
            cancelColor: "#00baff",
            confirmText: "确定",
            confirmColor: "#ed3f14",
            success: function(a) {
                a.cancel;
            }
        });
    }
    },
    iswxcs: function() {
        a.util.request({
            url: "entry/wxapp/wxcs",
            success: function(a) {
                console.log("温馨提示"), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#00baff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            },
            fail: function(a) {
                console.log(a), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#00baff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            }
        });
        var lastday=  Number(Date.parse(new Date())) + Number(86400000);
        wx.setStorageSync('lastday', lastday)
        var lastday = wx.getStorageSync('lastday')
        console.log('VIP缓存过期时间',lastday),
        this.setData({
            lastday : lastday,
        });
    },
    last: function() {
        wx.showModal({
            title: "温馨提示",
            content: "您今天已经看过啦\r\n明天再来观看吧",
            showCancel: true,
            cancelText: "取消",
            cancelColor: "#00baff",
            confirmText: "确定",
            confirmColor: "#ed3f14",
            success: function(a) {
                a.cancel;
            }
        });
    },
    gologin: function(){ wx.switchTab({ url: '../member/index', }) },
    loadMore: function() {
        0 == this.data.list.length || this.pageRequest(t);
    },
    onShareAppMessage: function(a) {
        var t = this;
        return a.from, {
            title: t.data.shareTitle,
            path: "/qsy_plus/pages/index/index?openid=" + wx.getStorageSync("share_openid"),
            imageUrl: this.data.url + this.data.imageUrl
        };
    },
    lingqu: function(o) {
        let keyindex=o.currentTarget.dataset.keyindex;
        var t = this, i = o.currentTarget.dataset.gongju_id, e = Date.parse(new Date()) / 1e3;
        t.data.jiaocheng ? n.get("ID_" + i) && n.get("ID_" + i + "_deadtime") > e ? t.setData({
            d_mask: !0,
            id_url: i,
            keyindex:keyindex
        }) : wx.showModal({
            title: "温馨提示",
            content: "观看一次完整视频广告，本资源24小时无广告领取。",
            confirmText: "观看视频",
            confirmColor: "#1AAD19",
            cancelText: "下次再说",
            success: function(o) {
                o.confirm && t.initVideoAd(function() {
                    t.setData({
                        id_url: i,
                        d_mask: !0,
                        keyindex:keyindex
                    });
                }, i);
            }
        }) : t.setData({
            d_mask: !0,
            id_url: i,
            keyindex:keyindex
        });
    },
    help: function() {
        let that = this;
        if (that.data.jiaocheng_img.length > 6) {
            wx.navigateTo({
                url:that.data.jiaocheng_img
            })
        }   
    },
    initVideoAd: function(o, t) {
        this.openVideoAd(function() {
            n.set("ID_" + t, "true", 86400), console.log(t), wx.showToast({
                title: "解锁成功，24小时内无广告领取！"
            }), o();
        }, function() {
            wx.showModal({
                title: "使用提示",
                content: "领取失败，请重新观看完广告，感谢您的支持！",
                showCancel: !1
            });
        }, function() {
            wx.showModal({
                title: "提示",
                content: "您目前暂无广告可看",
                showCancel: !1,
                success: function(t) {
                    t.confirm && o();
                }
            });
        }, t);
    },
    openVideoAd: function(o, n, i, e) {
        let _taht=this;
        let t=null;
        console.log("openVideoAd"), console.log(e), wx.createRewardedVideoAd ? (wx.showLoading({
            title: "视频加载中"
        }), t && (t.offClose(), t.offError(), t.offLoad()), (t = wx.createRewardedVideoAd({
            adUnitId: _taht.data.jiaocheng
        })).load().then(function() {
            wx.hideLoading(), t.onClose(function(t) {
                t && t.isEnded ? o && o() : (n && n(), console.log("播放中途退出"));
            }), t.show();
        }).catch(function(o) {
            wx.hideLoading();
        }), t.onLoad(function() {
            wx.hideLoading(), console.log("video 视频加载成功");
        }), t.onError(function(o) {
            wx.hideLoading(), i && i(), console.log(o);
        })) : wx.showModal({
            title: "提示",
            content: "您的微信版本过低，不支持此功能，请升级。"
        });
    },
    close_kefu: function() {
        this.Copy_url(this.data.keyindex), this.setData({
            d_mask: !1
        });
    },
    Copy_url: function(o) {
        console.log(this.data.ziyuan[o].path), wx.setClipboardData({
            data: this.data.ziyuan[o].path,
            success: function(o) {
                wx.hideToast(), wx.showModal({
                    title: "温馨提示",
                    content: "教程下载地址复制成功，请前往浏览器下载。",
                    confirmText: "朕知道了",
                    confirmColor: "#1AAD19",
                    showCancel: !1,
                    complete: function(o) {
                        console.log(o);
                    }
                });
            }
        });
    },
});