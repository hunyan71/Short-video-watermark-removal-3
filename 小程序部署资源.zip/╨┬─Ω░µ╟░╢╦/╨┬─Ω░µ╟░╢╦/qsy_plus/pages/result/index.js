var app = getApp(),
    n = ''
var util = require('../../resource/js/time.js');
let videoAd = null
Page({
    data: {
        winWidth: 0,
        winHeight: 0,
        currentTab: 0,
        progress: 0,
        percent: 0,
        videourl: '',
        videodown: '',
        imgurl: '',
        imgsurl: [],
        imgsdown: '',
        title: '',
        adid: '',
        api_url: '',
        api_url_img:'',
        maxheight: '',
        wxid: '',
        time: '',
        sponsor:'',
        modalHidden: true,
        day: '86400000',
        dayad: '',
        list_show: false,
        currentindex: 0,
        percents: 0,
        enterprise:''
    },
    onLoad: function() {
        var that = this
        let video = wx.getStorageSync('video')
        console.log(video)
        this.setData({
            enterprise:app.globalData.enterprise,
            api_url: app.globalData.api_url,
            api_url_img:app.globalData.api_url_img,
            progress: app.globalData.progress,
            videodown: video.downurl,
            videourl: decodeURIComponent(video.downurl),
            imgurl: decodeURIComponent(video.downimg) || '',
            title: video.title || '温馨提示：该视频没有标题哦',
            imgsurl: video.downimgs,
            imgsdown: decodeURIComponent(video.downimgs),
            adid: app.globalData.adid,
            wxid: app.globalData.wxid,
            time: Date.parse(new Date()),
            sponsor: wx.getStorageSync('zs')
        })
        if (app.globalData.ad > 0 ) {
            this.setData({
                dayad: app.globalData.day,  
            })
        }
        if (wx.createRewardedVideoAd) {
            console.log("视频预载中")
            videoAd = wx.createRewardedVideoAd({
                adUnitId: that.data.wxid
            })
            videoAd.onError(err => {
                console.log("视频加载失败")
            })
        }
        wx.getSystemInfo({
            success: function(res) {
                that.setData({
                    winWidth: res.windowWidth,
                    winHeight: res.windowHeight
                });
            }
        })
        var that = this
        if (that.data.winHeight > 500) {
            that.setData({
                maxheight: 400
            });
        }
        if (that.data.winHeight > 600) {
            that.setData({
                maxheight: 500
            });
        }
        if (that.data.winHeight > 670) {
            that.setData({
                maxheight: 550
            });
        }
    },

    bindChange: function(e) {
        var that = this;
        that.setData({
            currentTab: e.detail.current
        });
    },
    swichNav: function(e) {
        var that = this;
        if (this.data.currentTab === e.target.dataset.current) {
            return false;
        } else {
            that.setData({
                currentTab: e.target.dataset.current
            })
        }
    },

    goBack: function() {
        n ? (n.abort(), setTimeout(function() {
            wx.navigateBack({
                delta: 1
            })
        }, 1e3)) : wx.navigateBack({
            delta: 1
        })
    },

    getdataUrl: function(o) {
        return wx.getStorageSync(o)
    },

    copyvideo: function() {
        let that = this;
        wx.setClipboardData({
            data: that.data.videourl,
            success: function(res) {
                wx.showToast({
                    title: '复制成功',
                    icon: 'success',
                    duration: 800
                })
                setTimeout(
                    function() {
                        wx.hideToast({})
                    }, 800);
            }
        })
    },

    copyimg: function() {
        let that = this;
        wx.setClipboardData({
            data: that.data.imgurl,
            success: function(res) {
                wx.showToast({
                    title: '复制成功',
                    icon: 'success',
                    duration: 800
                })
                setTimeout(
                    function() {
                        wx.hideToast({})
                    }, 800);
            }
        })
    },

    downvideo: util.throttle(function() { //下载视频
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    that.video();
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                that.video();
            }
        } else {
            that.video()
        }
    }, 1500),

    downimg: util.throttle(function() { //下载封面
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    that.img();
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                that.img();
            }
        } else {
            that.img()
        }
    }, 1500),

    saveimgs(e) { //单个下载图集
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    var imgSrc = e.currentTarget.dataset.src
                                    console.log(imgSrc)
                                    wx.showLoading({
                                        title: '正在下载'
                                    })
                                    wx.downloadFile({
                                        url: imgSrc,
                                        success: function(res) {
                                            console.log(res);
                                            wx.saveImageToPhotosAlbum({
                                                filePath: res.tempFilePath,
                                                success: function(data) {
                                                    console.log(data)
                                                    wx.hideLoading()
                                                    wx.showToast({
                                                        title: '下载成功',
                                                        icon: 'success',
                                                        duration: 2000
                                                    })
                                                },
                                                fail: function(res) {
                                                    wx.showModal({
                                                        title: '提示',
                                                        content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                                        success: function(res) {
                                                            if (res.confirm) {
                                                                wx.openSetting()
                                                            }
                                                        }
                                                    })
                                                },
                                                complete(res) {
                                                    console.log(res);
                                                    wx.hideLoading()
                                                }
                                            })
                                        },fail:function(){
                                            wx.downloadFile({
                                                url: that.data.api_url_img + imgSrc,
                                                success: function(res) {
                                                    console.log(res);
                                                    wx.saveImageToPhotosAlbum({
                                                        filePath: res.tempFilePath,
                                                        success: function(data) {
                                                            console.log(data)
                                                            wx.hideLoading()
                                                            wx.showToast({
                                                                title: '下载成功',
                                                                icon: 'success',
                                                                duration: 2000
                                                            })
                                                        },
                                                        fail: function(res) {
                                                            wx.showModal({
                                                                title: '提示',
                                                                content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                                                success: function(res) {
                                                                    if (res.confirm) {
                                                                        wx.openSetting()
                                                                    }
                                                                }
                                                            })
                                                        },
                                                        complete(res) {
                                                            console.log(res);
                                                            wx.hideLoading()
                                                        }
                                                    })
                                                }
                                            })
                                        }
                                    })
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                var imgSrc = e.currentTarget.dataset.src
                console.log(imgSrc)
                wx.showLoading({
                    title: '正在下载'
                })
                wx.downloadFile({
                    url:imgSrc,
                    success: function(res) {
                        console.log(res);
                        wx.saveImageToPhotosAlbum({
                            filePath: res.tempFilePath,
                            success: function(data) {
                                console.log(data)
                                wx.hideLoading()
                                wx.showToast({
                                    title: '下载成功',
                                    icon: 'success',
                                    duration: 2000
                                })
                            },
                            fail: function(res) {
                                wx.showModal({
                                    title: '提示',
                                    content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                    success: function(res) {
                                        if (res.confirm) {
                                            wx.openSetting()
                                        }
                                    }
                                })
                            },
                            complete(res) {
                                console.log(res);
                                wx.hideLoading()
                            }
                        })
                    },fail:function(){
                        wx.downloadFile({
                            url: that.data.api_url_img + imgSrc,
                            success: function(res) {
                                console.log(res);
                                wx.saveImageToPhotosAlbum({
                                    filePath: res.tempFilePath,
                                    success: function(data) {
                                        console.log(data)
                                        wx.hideLoading()
                                        wx.showToast({
                                            title: '下载成功',
                                            icon: 'success',
                                            duration: 2000
                                        })
                                    },
                                    fail: function(res) {
                                        wx.showModal({
                                            title: '提示',
                                            content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                            success: function(res) {
                                                if (res.confirm) {
                                                    wx.openSetting()
                                                }
                                            }
                                        })
                                    },
                                    complete(res) {
                                        console.log(res);
                                        wx.hideLoading()
                                    }
                                })
                            },fail:function(){
                                
                            }
                        })
                    }
                })
            }
        } else {
            var imgSrc = e.currentTarget.dataset.src
            console.log(imgSrc)
            wx.showLoading({
                title: '正在下载'
            })
            wx.downloadFile({
                url:imgSrc,
                success: function(res) {
                    console.log(res);
                    wx.saveImageToPhotosAlbum({
                        filePath: res.tempFilePath,
                        success: function(data) {
                            console.log(data)
                            wx.hideLoading()
                            wx.showToast({
                                title: '下载成功',
                                icon: 'success',
                                duration: 2000
                            })
                        },
                        fail: function(res) {
                            wx.showModal({
                                title: '提示',
                                content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                success: function(res) {
                                    if (res.confirm) {
                                        wx.openSetting()
                                    }
                                }
                            })
                        },
                        complete(res) {
                            console.log(res);
                            wx.hideLoading()
                        }
                    })
                },fail:function(){
                    wx.downloadFile({
                        url: that.data.api_url_img + imgSrc,
                        success: function(res) {
                            console.log(res);
                            wx.saveImageToPhotosAlbum({
                                filePath: res.tempFilePath,
                                success: function(data) {
                                    console.log(data)
                                    wx.hideLoading()
                                    wx.showToast({
                                        title: '下载成功',
                                        icon: 'success',
                                        duration: 2000
                                    })
                                },
                                fail: function(res) {
                                    wx.showModal({
                                        title: '提示',
                                        content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                        success: function(res) {
                                            if (res.confirm) {
                                                wx.openSetting()
                                            }
                                        }
                                    })
                                },
                                complete(res) {
                                    console.log(res);
                                    wx.hideLoading()
                                }
                            })
                        }
                    })
                }
            })
        }
    },

    copyvideourl: util.throttle(function() { //复制视频下载链接
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    that.copyvideo();
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                that.copyvideo();
            }
        } else {
            that.copyvideo()
        }
    }, 1500),

    copyimgurl: util.throttle(function() { //复制封面下载链接
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    that.copyimg();
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                that.copyimg();
            }
        } else {
            that.copyimg()
        }
    }, 1500),

    copytitle: util.throttle(function() { //复制标题
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    that.copytitles();
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                that.copytitles();
            }
        } else {
            that.copytitles()
        }
    }, 1500),

    copyimgsurl(e) { //复制图集链接
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    var imgsurl = e.currentTarget.dataset.src
                                    console.log(imgsurl)
                                    wx.setClipboardData({
                                        data: imgsurl,
                                        success: function(res) {
                                            wx.showToast({
                                                title: '复制成功',
                                                icon: 'success',
                                                duration: 800
                                            })
                                            setTimeout(
                                                function() {
                                                    wx.hideToast({})
                                                }, 800);
                                        }
                                    })
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                var imgsurl = e.currentTarget.dataset.src
                console.log(imgsurl)
                wx.setClipboardData({
                    data: imgsurl,
                    success: function(res) {
                        wx.showToast({
                            title: '复制成功',
                            icon: 'success',
                            duration: 800
                        })
                        setTimeout(
                            function() {
                                wx.hideToast({})
                            }, 800);
                    }
                })
            }
        } else {
            var imgsurl = e.currentTarget.dataset.src
            console.log(imgsurl)
            wx.setClipboardData({
                data: imgsurl,
                success: function(res) {
                    wx.showToast({
                        title: '复制成功',
                        icon: 'success',
                        duration: 800
                    })
                    setTimeout(
                        function() {
                            wx.hideToast({})
                        }, 800);
                }
            })
        }
    },

    download: function() { //批量下载图集
        let that = this;
        if (that.data.dayad == 1) {
            var lasttime = wx.getStorageSync('lasttime');
            if (lasttime < that.data.time) {
                console.log('正在加载激励视频')
                wx.showModal({
                    title: '温馨提示',
                    content: '观看一次完整广告\r\n解锁24小时无限使用',
                    showCancel: true,
                    cancelText: "取消",
                    cancelColor: "#52bcff",
                    confirmText: "确定",
                    confirmColor: "#ed3f14",
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            videoAd.load()
                                .then(() => videoAd.show())
                                .catch(err => console.log(err.errMsg))
                            videoAd.onClose((status) => {
                                if (status && status.isEnded || status === undefined) {
                                    that.downloadFile(that.data.imgsurl).then(res => {
                                        that.setData({
                                            list_show: false,
                                        })
                                        wx.showToast({
                                            title: '下载完成'
                                        })
                                    })
                                    var outtime = Number(that.data.time) + Number(that.data.day);
                                    wx.setStorageSync("lasttime", outtime)
                                    console.log('当前时间', that.data.time)
                                    console.log('过期时间', outtime)
                                } else {
                                    console.log('用户没看完就关闭')
                                    wx.showToast({
                                        title: '观看完广告之后自动下载到手机哦',
                                        icon: "none",
                                        duration: 3000,
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                that.downloadFile(that.data.imgsurl).then(res => {
                    that.setData({
                        list_show: false,
                    })
                    wx.showToast({
                        title: '下载完成'
                    })
                })
            }
        } else {
            that.downloadFile(that.data.imgsurl).then(res => {
                that.setData({
                    list_show: false,
                })
                wx.showToast({
                    title: '下载完成'
                })
            })
        }
    },

    video() {
        let that = this;
        if (that.data.api_url) {
            wx.showToast({
                title: '开始下载！',
                icon: 'loading',
                duration: 1000
            })
            const downloadTask = wx.downloadFile({
                url: that.data.videodown,
                success(res) {
                    if (res.statusCode === 200) {
                        wx.hideToast({})
                        wx.saveVideoToPhotosAlbum({
                            filePath: res.tempFilePath,
                            success(res) {
                                that.setData({
                                    playurl: ""
                                })
                                wx.showModal({
                                    title: '下载成功',
                                    content: "请在手机相册中查看！",
                                    confirmColor: "#52bcff",
                                    showCancel: false,
                                    success: function(res) {}
                                })
                            }
                        })
                    }else{
                        that.dowww(that.data.videodown);
                    }
                },
                fail(res) {
                    that.dowww(that.data.videodown);
                    // wx.hideToast({})
                    // wx.showModal({
                    //     title: '下载失败',
                    //     content: '该视频无法直接下载，请复制无水印链接到手机QQ浏览器下载',
                    //     confirmColor: "#52bcff",
                    //     showCancel: false,
                    //     success: function(res) {
                    //         that.setData({})
                    //     }
                    // })
                }
            })
            downloadTask.onProgressUpdate((res) => {
                that.setData({
                    percent: String(res.progress)
                })
            })
        }
    },
    dowww(surl){
        let that = this;
        const downloadTask = wx.downloadFile({
            url: that.data.api_url + surl,
            success(res) {
                if (res.statusCode === 200) {
                    wx.hideToast({})
                    wx.saveVideoToPhotosAlbum({
                        filePath: res.tempFilePath,
                        success(res) {
                            that.setData({
                                playurl: ""
                            })
                            wx.showModal({
                                title: '下载成功',
                                content: "请在手机相册中查看！",
                                confirmColor: "#52bcff",
                                showCancel: false,
                                success: function(res) {}
                            })
                        }
                    })
                }else{

                }
            },
            fail(res) {
                wx.hideToast({})
                wx.showModal({
                    title: '下载失败',
                    content: '该视频无法直接下载，请复制无水印链接到手机QQ浏览器下载',
                    confirmColor: "#52bcff",
                    showCancel: false,
                    success: function(res) {
                        that.setData({})
                    }
                })
            }
        })
        downloadTask.onProgressUpdate((res) => {
            that.setData({
                percent: String(res.progress)
            })
        })
    },
    img() {
        let that = this;
        wx.showLoading({
            title: '正在下载'
        })
        wx.downloadFile({
            url: that.data.imgurl,
            success: function(res) {
                console.log(res);
                wx.saveImageToPhotosAlbum({
                    filePath: res.tempFilePath,
                    success: function(data) {
                        console.log(data)
                        wx.hideLoading()
                        wx.showToast({
                            title: '下载成功',
                            icon: 'success',
                            duration: 2000
                        })
                    },
                    fail: function(res) {
                        wx.showModal({
                            title: '温馨提示',
                            content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                            success: function(res) {
                                if (res.confirm) { //点击确定后前往授权设置页面
                                    wx.openSetting()
                                }
                            }
                        })
                    },
                    complete(res) {
                        console.log(res);
                        wx.hideLoading()
                    }
                })
            },fail:function(){
                wx.downloadFile({
                    url: that.data.api_url_img + that.data.imgurl,
                    success: function(res) {
                        console.log(res);
                        wx.saveImageToPhotosAlbum({
                            filePath: res.tempFilePath,
                            success: function(data) {
                                console.log(data)
                                wx.hideLoading()
                                wx.showToast({
                                    title: '下载成功',
                                    icon: 'success',
                                    duration: 2000
                                })
                            },
                            fail: function(res) {
                                wx.showModal({
                                    title: '温馨提示',
                                    content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                    success: function(res) {
                                        if (res.confirm) { //点击确定后前往授权设置页面
                                            wx.openSetting()
                                        }
                                    }
                                })
                            },
                            complete(res) {
                                console.log(res);
                                wx.hideLoading()
                            }
                        })
                    },fail:function(){
                        
                    }
                })
            }
        })
    },

    previewImage: function(t)  {
        if (this.data.dayad != 1) {
            wx.previewImage({
                current:  t.target.dataset.src,
                urls:  this.data.imgsurl
            });
        }
    },

    imgs(e) {
        let that = this;
        var imgSrc = e.currentTarget.dataset.src
        console.log(imgSrc)
        wx.showLoading({
            title: '正在下载'
        })
        wx.downloadFile({
            url:imgSrc,
            success: function(res) {
                console.log(res);
                wx.saveImageToPhotosAlbum({
                    filePath: res.tempFilePath,
                    success: function(data) {
                        console.log(data)
                        wx.hideLoading()
                        wx.showToast({
                            title: '下载成功',
                            icon: 'success',
                            duration: 2000
                        })
                    },
                    fail: function(res) {
                        wx.showModal({
                            title: '提示',
                            content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                            success: function(res) {
                                if (res.confirm) {
                                    wx.openSetting()
                                }
                            }
                        })
                    },
                    complete(res) {
                        console.log(res);
                        wx.hideLoading()
                    }
                })
            },fail:function(){
                wx.downloadFile({
                    url: that.data.api_url_img  + imgSrc,
                    success: function(res) {
                        console.log(res);
                        wx.saveImageToPhotosAlbum({
                            filePath: res.tempFilePath,
                            success: function(data) {
                                console.log(data)
                                wx.hideLoading()
                                wx.showToast({
                                    title: '下载成功',
                                    icon: 'success',
                                    duration: 2000
                                })
                            },
                            fail: function(res) {
                                wx.showModal({
                                    title: '提示',
                                    content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                                    success: function(res) {
                                        if (res.confirm) {
                                            wx.openSetting()
                                        }
                                    }
                                })
                            },
                            complete(res) {
                                console.log(res);
                                wx.hideLoading()
                            }
                        })
                    },fail:function(){
                        
                    }
                })
            }
        })
    },

    downloads: function() {
        this.downloadFile(this.data.imgsurl).then(res => {
            this.setData({
                list_show: false,
            })
            wx.showToast({
                title: '下载完成'
            })
        })
    },

    downloadFile(urls) {
        this.setData({
            list_show: true,
        })
        let promise = Promise.resolve()
        urls.forEach((url, index) => {
            promise = promise.then(() => {
                var ever = (10 / urls.length) * 10
                this.setData({
                    currentindex: index + 1,
                    percents: (index + 1) * ever
                })
                return this.downloads(url)
            })
        })
        return promise
    },

    downloads: function(url) {
        let that = this
        return new Promise((resolve, reject) => {
            wx.downloadFile({
                url: url,
                success: function(res) {
                    var temp = res.tempFilePath
                    wx.saveImageToPhotosAlbum({
                        filePath: temp,
                        success: function(res) {
                            resolve(res)
                        },
                        fail: function(err) {
                            that.setData({
                                list_show: false,
                            })
                        }
                    })
                },
                fail: function(err) {
                    wx.downloadFile({
                        url: that.data.api_url_img  + url,
                        success: function(res) {
                            var temp = res.tempFilePath
                            wx.saveImageToPhotosAlbum({
                                filePath: temp,
                                success: function(res) {
                                    resolve(res)
                                },
                                fail: function(err) {
                                    that.setData({
                                        list_show: false,
                                    })
                                }
                            })
                        },
                        fail: function(err) {
                            console.log(err, "err")
                            reject(err)
                        }
                    })
                }
            })
        })
    },

    copyimgs: function(e) {
        var imgsurl = e.currentTarget.dataset.src
        console.log(imgsurl)
        wx.setClipboardData({
            data: imgsurl,
            success: function(res) {
                wx.showToast({
                    title: '复制成功',
                    icon: 'success',
                    duration: 800
                })
                setTimeout(
                    function() {
                        wx.hideToast({})
                    }, 800);
            }
        })
    },
    copytitles: function() {
        let that = this;
        wx.setClipboardData({
            data: that.data.title,
            success: function() {
                wx.showToast({
                    title: '复制成功',
                    icon: 'success',
                    duration: 800
                })
                setTimeout(
                    function() {
                        wx.hideToast({})
                    }, 800);
            }
        })
    },
    help: function() {
        wx.navigateTo({
            url: '../shibai/index',
        })
    },
    invite: function() {
        wx.navigateTo({
            url: '../cishu/index',
        })
    },

  buttonTap: function() {
    this.setData({
         modalHidden: false
    })
    },
  modalCandel: function() {
    this.setData({
         modalHidden: true
    })
    },
     modalConfirm: function() {
    let that = this;
    that.setData({
         modalHidden: true
    })
        wx.downloadFile({
        url: that.data.api_url_img + that.data.sponsor,
        success: function(res) {
            console.log(res);
            wx.saveImageToPhotosAlbum({
                filePath: res.tempFilePath,
                success: function(data) {
                    console.log(data)
                    wx.hideLoading()
                    wx.showToast({
                        title: '二维码下载成功',
                        icon:'none'
                    })
                      
                },
                fail: function(res) {
                    wx.showModal({
                        title: '温馨提示',
                        content: '用户拒绝授权访问本地相册将导致图片无法保存！如需继续操作，请点击确定前往开启授权。',
                        success: function(res) {
                            if (res.confirm) { 
                                wx.openSetting()
                            }
                        }
                    })
                },
                complete(res) {
                    console.log(res);
                    wx.hideLoading()
                }
            })
        }
    })

    }
});