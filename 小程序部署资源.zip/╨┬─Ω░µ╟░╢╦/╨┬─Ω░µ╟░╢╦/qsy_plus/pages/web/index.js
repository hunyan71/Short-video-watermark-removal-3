Page({
    data: {
        url: ""
    },
    onLoad: function(n) {
        this.setData({
            url: n.url
        });
    },
    onReady: function() {},
    onShow: function(n) {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});