function t(t, a, o) {
    return a in t ? Object.defineProperty(t, a, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = o, t;
  }
  var time = require('../../resource/js/time.js');
  var a = require("../../../fast.fd521.cn.js"),
    e = getApp();
  var util = require('../../resource/js/lanch.js');
  const md5 = require('../../resource/js/md5.js');
  var app = getApp();
  Page({
    data: (a = {
            showTopTips: !1,
            color: "#52bcff",
            errorMessage: "错误提示",
            inputvalue: "",
            loginState: 0,
            appname: "",
            title: "",
            nowtime: "",
            description: "",
            buttonjiexi: "recommend",
            qqgourp: "",
            shareTitle: "",
            api_url: "",
            helpUrl: "",
            adId: "",
            adcpid: "",
            adspid: "",
            share_img: "",
            progress: 0,
            adImg: "",
            adindexImg: "",
            adText: "",
            copyText: null,
            isAudit: "0",
            tuijian: "0",
            downurl: "",
            jlnum: "",
            isMember: "",
            url: "",
            name: 0,
            userInfo: "",
            tuijian: 0,
            dayad: "",
            dayadid: "",
            vipad: "",
            sponsor: "",
            openpl: "",
            indicatorDots: true,
            autoplay: true,
            interval: 6000,
            duration: 800,
            circular: true,
            tiao_title:'',
            tiao_title_url:''
        }, t(a, "progress", ""), t(a, "playurl", ""), t(a, "adUnitIds", ""), t(a, "scrollTop", 0), t(a, "playimg", ""), t(a, "playimgs", ""),
        t(a, "showAddMeBtn", !0), t(a, "isTop", 0), t(a, "jiexibut", ""), a),
    onLoad: function(t) {
        wx.setNavigationBarTitle({
            title: "去水印小程序",
        })
        if (wx.getStorageSync("invita_openid").length < 5) {
            var a = t.openid || "";
            wx.setStorageSync("invita_openid", a);
        }
    },
  
    swiperChange: function(e) {
        this.setData({
            swiperCurrent: e.detail.current
        })
    },
    onShow: function(res) {
        let that = this;
        wx.getClipboardData({
            success: function(res) {
                let result = util.handleUrl(res.data);
                if (result && result !== that.data.inputvalue) {
                    let txturl = result.substring(0, 30)
                    wx.showModal({
                        title: '检测到视频链接，是否粘贴？',
                        content: txturl.length >= 30 ? txturl + '...' : result,
                        showCancel: true, //是否显示取消按钮
                        cancelText: "取消", //默认是“取消”
                        cancelColor: '#52bcff', //取消文字的颜色
                        confirmText: "粘贴", //默认是“确定”
                        confirmColor: '#52bcff', //确定文字的颜色
                        success: function(res) {
                            if (res.cancel) {} else {
                                that.setData({
                                    inputvalue: result,
                                    downurl: ""
                                })
                            }
                        },
                        fail: function(res) {},
                        complete: function(res) {},
                    })
  
                }
            },
            fail: function(res) {},
            complete: function(res) {},
        })
        that.index()
        wx.checkSession({
            success: function(e) {
                console.log("没过期");
                that.setData({
                    loginState: 1
                })
            },
            fail: function() {
                console.log("过期了");
                that.setData({
                    loginState: 0
                })
            }
        });
    },
  
    tipKeFuMsg: function(t) {
        let that = this;
        wx.playBackgroundAudio({
            dataUrl: "http://tts.baidu.com/text2audio?idx=1&tex=" + encodeURIComponent(that.data.description) + "&cuid=baidu_speech_demo&cod=2&lan=zh&ctp=1&pdt=1&spd=5&per=0&vol=5&pit=5"
        });
    },
    onClickAddToMinProgramCloseBtn: function() {
        wx.setStorageSync("showAddMeFlag" + this.data.time, !0), this.setData({
            showAddMeBtn: !1
        });
  
    },
    start: function() {
        let that = this;
        that.setData({
            color: '#ffb428'
        })
    },
    end: function() {
        let that = this;
        that.setData({
            color: '#faa508'
        })
    },
    warn: function() {
        wx.showModal({
            title: '温馨提示',
            content: "请先登陆!",
            confirmColor: "#52bcff",
            showCancel: false,
            success: function(res) {
                wx.navigateTo({ url: '../member/index', })
            }
        })
    },
    updateUserInfo: function(result) {
        var that = this;
        if (result.detail.userInfo) {
            that.setData({
                loginState: 1
            })
            app.util.getUserInfo(function(userInfo) {
                app.util.request({
                    'url': 'entry/wxapp/login',
                    'cachetime': '30',
                    data: {
                        inviterOpenid: wx.getStorageSync("invita_openid")
                    },
                    success(res) {
                        wx.setStorageSync("share_openid", res.data.data.openid);
                        that.index(),
                            that.query()
                    },
                    fail(res) {
                        that.setData({
                            loginState: 0
                        })
                    }
                })
            }, result.detail)
        } else {
            that.setData({
                loginState: 0
            })
        }
  
    },
    changeLoginState: function() {
        this.setData({
            loginState: 0
        })
    },
    invalue: function(e) {
        this.setData({
            inputvalue: e.detail.value
        })
    },
    clear: function() {
        this.setData({
            inputvalue: ''
        })
    },
    index: function() {
        let that = this;
        let adIdList = [];
        app.util.request({
            'url': 'entry/wxapp/index',
            success(res) {
                    wx.getStorageSync("api_url", res.data.data.index.api_url),
                    wx.setStorageSync("share", res.data.data.index.share_img),
                    wx.setStorageSync("zs", res.data.data.index.sponsor),
                    console.log(res.data.data)
                    that.setData({
                        title: res.data.data.index.title,
                        url: res.data.data.url,
                        appname: res.data.data.index.app_name,
                        description: res.data.data.index.description,
                        jlnum: res.data.data.index.adtext,
                        name: res.data.data.name,
                        vipad: res.data.data.vipad,
                        shareTitle: res.data.data.index.share_title,
                        api_url: res.data.data.index.api_url,
                        share_img: res.data.data.index.share_img,
                        text: res.data.data.index.timetitle,
                        adId: res.data.data.index.ad_id,
                        adcpid: res.data.data.index.adimg,
                        
                        adUnitIds: res.data.data.index.adtext,
                        adImg: res.data.data.index.adimg,
                        adindexImg: res.data.data.index.adindexImg,
                        adText: res.data.data.index.adtext,
                        copyText: res.data.data.index.copytext,
                        isAudit: wx.setStorageSync("isAudit"),
                        isAudit: res.data.data.index.isaudit,
                        adspid: res.data.data.index.help_url,
                        progress: res.data.data.index.progress,
                        tiao_title_url: res.data.data.index.tiao_title_url,
                        tiao_title: res.data.data.index.tiao_title,
                         tuijian: res.data.data.tuijian,
                        sponsor: res.data.data.index.sponsor,
                        openpl: res.data.data.index.urltitle2,
                        jiexibut: res.data.data.index.api_url ? '下载视频' : '解析视频'
                    }),
                    app.globalData.api_url = res.data.data.index.api_url,
                    app.globalData.api_url_img = res.data.data.index.api_url_img,
                    app.globalData.progress = res.data.data.index.progress,
                    app.globalData.adid = res.data.data.index.ad_id,
                    app.globalData.wxid = res.data.data.index.dayadid,
                    app.globalData.day = res.data.data.index.dayad,
                    app.globalData.ad = res.data.data.vipad,
                    app.globalData.banner = res.data.data.index.copytext,
                    console.log(res.data.data.index.enterprise+'------------');
                    app.globalData.enterprise = res.data.data.index.enterprise,
                    wx.setNavigationBarTitle({
                        title: res.data.data.index.app_name
                    })
                setTimeout(function() {
                    let interstitialAd = null;
                    if (wx.createInterstitialAd) {
                        interstitialAd = wx.createInterstitialAd({
                            adUnitId: that.data.adcpid
                        })
                    }
                    if (interstitialAd) {
                        interstitialAd.show().catch((err) => {
                            console.error(err);
                        })
                    }
  
                }, 9000);
                var name = that.data.name
                setTimeout(function() {
                    if (name == 2) {
                        wx.showModal({
                            title: "温馨提示",
                            content: "登录享受极速下载",
                            confirmColor: "#52bcff",
                            showCancel: !1,
                            success: function(t) {
                                that.up();
                            }
                        });
                    }
                }, 1000)
            }
        })
    },
  
    paste: function() {
        let that = this;
        wx.getClipboardData({
            success: function(res) {
                let result = util.handleUrl(res.data);
                if (result) {
                    that.setData({
                        inputvalue: result
                    })
                } else(
                    wx.showModal({
                        title: '温馨提示',
                        content: "没有可用的链接",
                        confirmColor: "#52bcff",
                        showCancel: false,
                        success: function(res) {
                            that.setData({
                                result: ''
                            })
                        }
                    })
                )
  
            }
        })
  
    },
    query0: time.throttle(function(e) {
        let that = this;
        let gurl = that.isUrl(that.data.inputvalue);
        var string = gurl;
        string = md5.md5(that.data.inputvalue);
        if (gurl) {
            wx.showLoading({
                title: '正在解析'
            })
            if (that.data.openpl.length>0) {
            app.util.request({
                'url': 'entry/wxapp/query',
                'data': {
                    url: gurl,
                    encrypt: string
                },
                success(res) {
                    console.log(res)
                    wx.setStorage({
                        key: "video",
                        data: res.data.data
                    })
                    wx.navigateTo({
                        url: '../result/index'
                    })
                },
                fail(res) {
                    let err = res.data.errno
                    wx.hideToast({})
                    wx.showModal({
                        title: '温馨提示',
                        content: res.data.message,
                        confirmColor: "#52bcff",
                        showCancel: false,
                        success: function(res) {
                            if (err === 3) {
                                wx.removeStorage({
                                    key: 'userInfo',
                                    success(res) {
                                        that.setData({
                                            loginState: "0"
                                        })
                                        wx.reLaunch({
                                            url: '../member/index'
                                        })
                                    }
                                })
                            }
                        }
                    })
  
                }
            })
          }else{
            app.util.request({
                'url': 'entry/wxapp/query',
                'data': {
                    url: gurl,
                    encrypt: string
                },
                success(res) {
                    console.log(res)
                    wx.setStorage({
                        key: "video",
                        data: res.data.data
                    })
                    wx.navigateTo({
                        url: '../result/index'
                    })
                },
                fail(res) {
                    let err = res.data.errno
                    wx.hideToast({})
                    wx.showModal({
                        title: '温馨提示',
                        content: res.data.message,
                        confirmColor: "#52bcff",
                        showCancel: false,
                        success: function(res) {
                            if (err === 3) {
                                wx.removeStorage({
                                    key: 'userInfo',
                                    success(res) {
                                        that.setData({
                                            loginState: "0"
                                        })
                                        wx.reLaunch({
                                            url: '../member/index'
                                        })
                                    }
                                })
                            }
                        }
                    })
  
                }
            })
          }
        }
    }, 3000),
  
    query: time.throttle(function(e) {
        let that = this;
        let gurl = that.isUrl(that.data.inputvalue);
        var string = gurl;
        string = md5.md5(that.data.inputvalue);
        if (gurl) {
            wx.showLoading({
                title: '正在解析'
            })
            if (that.data.openpl.length>0) {
            app.util.request({
                'url': 'entry/wxapp/query',
                'data': {
                    url: gurl,
                    encrypt: string
                },
                success(res) {
                    console.log(res)
                    wx.setStorage({
                        key: "video",
                        data: res.data.data
                    })
                    wx.navigateTo({
                        url: '../result/index'
                    })
                },
                fail(res) {
                    let err = res.data.errno
                    wx.hideToast({})
                    if (err === 5) {
                        wx.showModal({
                            title: '温馨提示',
                            content: '您的次数已用完！\r\n观看完广告后可获得VIP会员\r\n会员有效期间内可无限制解析视频',
                            showCancel: true,
                            cancelText: "下次再说",
                            cancelColor: '#52bcff',
                            confirmText: "观看视频",
                            confirmColor: '#ed3f14',
                            success: function(res) {
                                res.cancel || that.wxcs();
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../index/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 0) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../index/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 1) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../member/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 3) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../member/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                }
            })
          }else{
            app.util.request({
                'url': 'entry/wxapp/query',
                'data': {
                    url: gurl,
                    encrypt: string
                },
                success(res) {
                    console.log(res)
                    wx.setStorage({
                        key: "video",
                        data: res.data.data
                    })
                    wx.navigateTo({
                        url: '../result/index'
                    })
                },
                fail(res) {
                    let err = res.data.errno
                    wx.hideToast({})
                    if (err === 5) {
                        wx.showModal({
                            title: '温馨提示',
                            content: '您的次数已用完！\r\n观看完广告后可获得VIP会员\r\n会员有效期间内可无限制解析视频',
                            showCancel: true,
                            cancelText: "下次再说",
                            cancelColor: '#52bcff',
                            confirmText: "观看视频",
                            confirmColor: '#ed3f14',
                            success: function(res) {
                                res.cancel || that.wxcs();
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../index/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 0) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../member/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 1) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../member/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                    if (err === 3) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            confirmColor: "#52bcff",
                            showCancel: false,
                            success: function(res) {
                                if (err === 3) {
                                    wx.removeStorage({
                                        key: 'userInfo',
                                        success(res) {
                                            that.setData({
                                                loginState: "0"
                                            })
                                            wx.reLaunch({
                                                url: '../member/index'
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    }
                }
            })
          }
        }
    }, 3000),
  
  
    wxcs: function() {
        var a = this,
            t = wx.createRewardedVideoAd({
                adUnitId: a.data.adspid
            });
        t.load().then(function() {
            return t.show();
        }).catch(function(a) {
            return console.log(a.errMsg);
        }), t.onError(function(t) {
            console.log(t), a.error();
        }), t.onClose(function(i) {
            t.offClose(), i && i.isEnded || void 0 === i ? a.cs() : wx.showModal({
                title: "温馨提示",
                content: "看完广告后可获得\r\n无限解析VIP会员奖励!",
                showCancel: !0,
                cancelText: "不看了",
                cancelColor: "#52bcff",
                confirmText: "继续看",
                confirmColor: "#ed3f14",
                success: function(t) {
                    t.cancel || a.wxcs();
                }
            });
        });
    },
  
    cs: function() {
        let that = this;
        app.util.request({
            url: "entry/wxapp/wxcs",
            data: {
                tsnum: that.data.jlnum
            },
            success: function(a) {
                console.log("温馨提示"), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            },
            fail: function(a) {
                console.log(a), wx.showModal({
                    title: "温馨提示",
                    content: a.data.message,
                    confirmColor: "#52bcff",
                    showCancel: !1,
                    success: function(a) {
                        a.cancel;
                    }
                });
            }
        });
    },
    error: function() {
        wx.showModal({
            title: '温馨提示',
            content: "观看失败",
            confirmColor: "#52bcff",
            showCancel: false,
        })
    },
  
    isUrl: function(url) {
        var that = this;
        if (url.length == 0) {
            wx.showModal({
                title: '温馨提示',
                content: "网址不能为空",
                confirmColor: "#52bcff",
                showCancel: false,
            })
            return false;
        } else {
            let result = util.handleUrl(url);
            if (result) {
                return result;
            } else {
                wx.showModal({
                    title: '温馨提示',
                    content: "请输入正确的网址",
                    confirmColor: "#52bcff",
                    showCancel: false,
                    success: function(res) {
                        that.setData({
                            result: ''
                        })
                    }
                })
                return false;
            }
        }
    },
    help: function() {
        let that = this;
        if (that.data.tiao_title_url.length > 6) {
            wx.navigateTo({
                url: '../../pages/web/index?url=' + that.data.tiao_title_url
            })
        } else {
            wx.navigateTo({
                url: '../help/index'
            })
        }
    },
    toduihuan: function() {
        wx.navigateTo({
            url: '../keypay/keypay'
        })
    },
  
    up: function() {
        wx.getUserProfile({
            desc: '用于完善用户资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
            success: (res) => {
                this.setData({
                    userInfo: res.userInfo,
                    hasUserInfo: true
                  })
                app.util.request({
                    url: "entry/wxapp/Userup",
                    data: {
                        name: res.userInfo.nickName,
                        head: res.userInfo.avatarUrl,
                        gender: res.userInfo.gender,
                        city: res.userInfo.city,
                        province: res.userInfo.province,
                    },
                    method: 'GET',
                    header: {'content-type': 'application/json'},
                 }
                );
              },
              fail: function(a) {
                  console.log(a), wx.showModal({
                      title: "获取信息失败",
                      content: "请允许授权以便为您提供服务",
                      confirmColor: "#52bcff",
                      showCancel: !1,
                      success: function(a) {
                        wx.getUserProfile({
                            desc: '用于完善用户资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
                            success: (res) => {
                                this.setData({
                                    userInfo: res.userInfo,
                                    hasUserInfo: true
                                  })
                                app.util.request({
                                    url: "entry/wxapp/Userup",
                                    data: {
                                        name: res.userInfo.nickName,
                                        head: res.userInfo.avatarUrl,
                                        gender: res.userInfo.gender,
                                        city: res.userInfo.city,
                                        province: res.userInfo.province,
                                    },
                                    method: 'GET',
                                    header: {'content-type': 'application/json'},
                                 }
                                );
                              },
                              fail: function(a) {
                                  console.log(a), wx.showModal({
                                      title: "获取信息失败",
                                      content: "我一定会回来的 ~",
                                      confirmColor: "#52bcff",
                                      showCancel: !1,
                                      success: function(a) {                                 
                                      }
                                  });
                              }
                          })         
                     }
                  });
              }
          })
      },
      
    onPageScroll: function(t) {
        var a = this;
        t.scrollTop <= 0 ? t.scrollTop = 0 : t.scrollTop > wx.getSystemInfoSync().windowHeight && (t.scrollTop = wx.getSystemInfoSync().windowHeight),
            t.scrollTop > this.data.scrollTop || t.scrollTop >= this.data.scrollHeight ? console.log("向下滚动") : console.log("向上滚动"),
            setTimeout(function() {
                a.setData({
                    scrollTop: t.scrollTop
                });
            }, 0);
    },
    onClose1: function(t) {
        this.setData({
            scrollTop: 0
        });
    },
    _eventbackToTop: function() {
        wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        });
    },
    gomd5: function() {
        wx.switchTab({
            url: "/qsy_plus/pages/md5/index"
        });
    },
  
    onShareAppMessage: function(t) {
        return t.from, {
            title: this.data.shareTitle,
            path: "/qsy_plus/pages/index/index?openid=" + wx.getStorageSync("share_openid"),
            imageUrl: this.data.share_img
        };
    },
  
    onShareTimeline() {
        return {
            title: this.data.shareTitle,
            path: "/qsy_plus/pages/index/index?openid=" + wx.getStorageSync("share_openid"),
            imageUrl: this.data.share_img
        }
    },


    
  });