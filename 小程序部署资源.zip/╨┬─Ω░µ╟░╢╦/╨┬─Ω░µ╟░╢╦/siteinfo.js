﻿请移步
https://fast.fd521.cn/user/xcx_wxapp.php
获取您的配置文件