var app = getApp()
Component({
  properties: {
    isCanDraw: {
      type: Boolean,
      value: false,
      observer(newVal, oldVal) {
        newVal && this.drawPic()
      }
    }
  },
  data: {
    isModal: false,
    imgDraw: {}, 
    sharePath: '', 
    qrcode: '',
    down: '0',
    visible: false
  },
  methods: {
    handlePhotoSaved() {
      this.savePhoto(this.data.sharePath)
    },
    handleClose() {
      this.setData({
        visible: false,
      })
    },
    drawPic() {
      if (this.data.sharePath) {
        this.setData({
          visible: true,
        })
        this.triggerEvent('initData') 
        return
      }
      wx.showLoading({
        title: '正在生成中'
      })
      let downurl = wx.setStorageSync("api_url");
      let qrcode = wx.getStorageSync("qrcode");
      console.log(downurl)
      this.setData({
        imgDraw: {
          width: '750rpx',
          height: "1200rpx",
              background: app.globalData.api_url + '/images/119f8bdcd07b7.png',
          views: [
            {
              type: 'image',
              url: app.globalData.api_url + qrcode,
              css: {
                top: '900rpx',
                left: '75rpx',
                width: '220rpx',
                height: '220rpx'
              }
            },
          ]
        }
      })

    },
    onImgErr(e) {
      wx.hideLoading()
      wx.showToast({
        title: '生成分享图失败，请刷新页面重试'
      })
    },
    onImgOK(e) {
      wx.hideLoading()
      this.setData({
        sharePath: e.detail.path,
        visible: true,
      })
      //通知外部绘制完成，重置isCanDraw为false
      this.triggerEvent('initData', {
        sharePath: e.detail.path
      });
      wx.saveImageToPhotosAlbum({
        filePath: this.data.sharePath,
        success: (res) => {
          wx.showToast({
            title: '保存成功',
            icon: 'success'
          })
          setTimeout(() => {
            this.setData({
              visible: false
            })
          }, 300000)
        },
        fail: (res) => {
          wx.getSetting({
            success: res => {
              let authSetting = res.authSetting
              if (!authSetting['scope.writePhotosAlbum']) {
                this.setData({
                  isModal: true
                })
              }
            }
          })
          setTimeout(() => {
            wx.hideLoading()
            this.setData({
              visible: false
            })
          }, 300000)
          this.setData({
            down: '1',
          })
        }
      })
  
    },

    save(){
      wx.saveImageToPhotosAlbum({
        filePath: this.data.sharePath,
        success: (res) => {
          wx.showToast({
            title: '保存成功',
            icon: 'success'
          })
          setTimeout(() => {
            this.setData({
              visible: false
            })
          }, 300000)
        },
        fail: (res) => {
          wx.getSetting({
            success: res => {
              let authSetting = res.authSetting
              if (!authSetting['scope.writePhotosAlbum']) {
                this.setData({
                  isModal: true
                })
              }
            }
          })
          setTimeout(() => {
            wx.hideLoading()
            this.setData({
              visible: false
            })
          }, 300000)
          this.setData({
            down: '1',
          })
        }
      })
    },
  },
})
