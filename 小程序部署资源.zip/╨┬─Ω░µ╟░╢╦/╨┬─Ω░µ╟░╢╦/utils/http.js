const tips = {
  1: '抱歉，出现了一个错误',
  2: '请先登录'
}

class HTTP {
  request({
    url,
    data = {},
    method = 'GET'
  }) {
    return new Promise((resolve, reject) => {
      this._request(url, resolve, reject, data, method)
    })
  }
  _request(url, resolve, reject, data = {}, method = 'GET') {
    req(url, resolve, reject, data, method);

    function req(url, resolve, reject, data, method) {
      wx.request({
        url: url,
        method: method,
        data: data,
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: (res) => {
          resolve(res.data)
        },
        fail: (err) => {
          reject()
          wx.showModal({
            title: '提示',
            content: '网络请求超时',
            confirmText: '重试',
            success(res) {
              if (res.confirm) {
                req(url, resolve, reject, data, method);
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      })
    }
  }
}

export {
  HTTP
}